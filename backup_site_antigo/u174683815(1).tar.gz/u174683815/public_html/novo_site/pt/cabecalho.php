<header>
    	
        	<a href="index.php" title="Joelini"><img src="estru/logo.png" alt="Joelini"></a>
            
            <nav>
            	
                <ul>
                	<li><a href="index.php" title="" class="<?php echo $menuInicio ?>">Início</a></li>
                    <li><a href="empresa.php" title="" class="<?php echo $menuEmpresa ?>">Empresa</a>
                        <ul class="submenu">
                           <li><a href="linha_do_tempo.php" title="">Linha do Tempo</a></li>
                           <li><a href="palavra_do_fundador.php" title="">Diferenciais Joelini</a></li>
                           <!--<li><a href="missao_visao_valores.php" title="">Missão, Visão e Valor</a></li>-->
                        </ul>
                     </li>
                    <li><a href="produtos.php" title="" class="<?php echo $menuProdutos ?>">Produtos</a></li>
                    <li><a href="consultores.php" title="" class="<?php echo $menuConsultores ?>">Consultores</a></li>
                    <li><a href="news.php" title="" class="<?php echo $menuNews ?>">News</a></li>
                    <li><a href="contato.php" title="" style="border-right:none;" class="<?php echo $menuFaleconosco ?>">Fale Conosco</a></li>
                </ul>
            
            
            </nav>
    
	</header>