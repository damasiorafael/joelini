<footer>
    
 <a href="https://www.facebook.com/Joelini.Ferragens" title="Siga-nos no Facebook" target="_blank"><img src="estru/face.png" alt="Facebook" width="30" height="30"></a>
 
 <a href="https://twitter.com/JoeliniFerragem" title="Siga-nos no Twitter" target="_blank"><img src="estru/twitter.png" alt="Twitter" width="30" height="30"></a>
 
 <a href="https://plus.google.com/u/0/103101609062419327811/posts" title="Siga-nos no Google+" target="_blank"><img src="estru/google+.png" alt="Google" width="30" height="30"></a>
        
        <p>Copyright &copy; <?php echo date('Y'); ?> - 2017 </p>
    <img src="../pt/imagens2/21anos.png" style="
    margin-top: -60px;
    margin-left: 954px;
">
</footer>