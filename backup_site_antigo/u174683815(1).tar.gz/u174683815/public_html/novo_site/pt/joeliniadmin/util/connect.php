<?php

define('DB_HOST', 'mysql.onda.com.br');
define('DB_USER', 'M22556_01');
define('DB_PASSWORD', 'imFkPuf8');
define('DB_NAME', 'M22556_01');

?>