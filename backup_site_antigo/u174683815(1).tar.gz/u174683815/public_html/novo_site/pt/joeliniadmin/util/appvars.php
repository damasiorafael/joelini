<?php
	define('JOELINI_UPLOADPATH_THUBNAILS', '../imagens/imgP/');
	define('JOELINI_UPLOADPATH_NORMAL', '../imagens/imgG/');
	
	define('JOELINI_UPLOADPATH_THUBNAILS_FRONTEND', 'imagens/imgP/');
	define('JOELINI_UPLOADPATH_NORMAL_FRONTEND', 'imagens/imgG/');
	
	
	
	define('JOELINI_UPLOADPATH_CAPA_CATEGORIA', '../imagens/capa_categoria/');
	define('JOELINI_UPLOADPATH_CAPA_CATEGORIA_FRONTEND', 'imagens/capa_categoria/');
	
	define('JOELINI_UPLOADPATH_CONSULTORES_BACKEND', '../imagens/consultor/');
	define('JOELINI_UPLOADPATH_CONSULTORES_FRONTEND', 'imagens/consultor/');
	
	
	define('JOELINI_UPLOADPATH_BANNER_BACKEND', '../imagens/banner/');
	define('JOELINI_UPLOADPATH_BANNER_FRONTEND', 'imagens/banner/');
	

	define('JOELINI_MAXFILESIZE', 2100000000);
	define('JOELINI_MAXFILESIZE_CAPA', 2100000000);
?>