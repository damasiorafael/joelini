<?php $title = 'Home - Joelini Ferragens para Móveis'; ?>
<?php require 'header.php'; ?>

<body>


	<?php require 'cabecalho.php'; ?>
    
    
    <section id="all">
    
 
  
  
    	
    
    
    
  <?php require 'footer.php'; ?>
    
    </section><!--/all-->
    
  
  
    
    


</body>
</html>