<?php $title = 'Empresa - Joelini Ferragens para Móveis'; ?>
<?php require 'header.php'; ?>

<body>

	<?php $menuEmpresa = 'active' ?>
	<?php require 'cabecalho.php'; ?>
    
    
    <section id="all">
    
 
  <div class="back_conteudo">
  
  	<section id="conteudo">
 
    
    
    
    	<section id="empresa">
        
        
        	<div style="width:944px; height:420px; overflow:hidden; overflow-x: scroll;">
        
        
        	<div class="linha_do_tempo">
            	<h2>Linha do Tempo</h2>
                
           
                
                <article style="background: url(estru/bg_linha_tempo2.png) no-repeat bottom center;">
                
                <h3 style="color:#ccad6e !important;">1977</h3>
                <p style="color:#ccad6e !important;">(Santiago - Chile) Rene Quezada e família se mudam para o Brasil.</p>
                
                <img src="estru/imagens_linha_do_tempo/1977.png" alt="Imagem Linha do Tempo 1977">
                
                </article>
                
                <article style="background: url(estru/bg_linha_tempo2.png) no-repeat bottom center;">
                
                <h3 style="color:#ccad6e !important;">1987</h3>
                <p style="color:#ccad6e !important;">(São Paulo - SP) Rene Decide criar sua própria ferramentaria nos fundos de sua própria casa</p>
                <p style="color:#ccad6e !important;">&nbsp;</p>
                
                
                <img src="estru/imagens_linha_do_tempo/1987.png" alt="Imagem Linha do Tempo 1987" class="imagem_1987">
                
                </article>
                
                <article>
                
                <h3>1992</h3>
                <p>Mudança da empresa para</p>
                <p> Arapongas/PR e mudança no</p>
                <p> nome para JOELINI.</p>
                <p>&nbsp;</p>
                
                
                <img src="estru/imagens_linha_do_tempo/1992.png" alt="Imagem Linha do Tempo 1992" class="imagem_1996">
                
                </article>
                
                <article>
                
                <h3>1995</h3>
                <p>Aquisição da primeira</p>
                <p>injetora de plásticos.</p>
                 <img src="estru/imagens_linha_do_tempo/1995.png" alt="Imagem Linha do Tempo 1995" class="imagem_1998">
</article>
                
                
                <article>
                
                <h3>1997</h3>
                <p>Calceiro, o primeiro produto</p>
                <p>para móveis.</p>
                <img src="estru/imagens_linha_do_tempo/1997.png" alt="Imagem Linha do Tempo 1997" class="imagem_1998">
</article>
                
                </article>
                
                
                <article>
                
                <h3>1998</h3>
                <p>&quot;Participação da primeira edição FIQ.</p>
                <p>Mudança para galpão de 700m².</p>
                <img src="estru/imagens_linha_do_tempo/1998.png" alt="Imagem Linha do Tempo 1998" class="imagem_1998">
                </article>
                
                
                <article style="margin-left:30px;">
                
                <h3>2000</h3>
                <p>Falecimento  do fundador,</p>
                <p>  Sr. Rene.</p>
                <img src="estru/imagens_linha_do_tempo/2000.png" alt="Imagem Linha do Tempo 2000" class="imagem_1998">
                </article>
                
                
                 <article style="margin-left:-50px;">
                
                <h3>2002</h3>
                <p>Ampliação da linha de </p>
                <p>produtos plásticos.</p>
                 <img src="estru/imagens_linha_do_tempo/2002.png" alt="Imagem Linha do Tempo 2002" class="imagem_1998">
                </article>
                
                
                <article>
                
                <h3>2004</h3>
                <p>Nova identidade visual.</p>
                <p>&nbsp;</p>
                <img src="estru/imagens_linha_do_tempo/2004.png" alt="Imagem Linha do Tempo 2004" class="imagem_1998">
                </article>
            
  <article style="margin-left: 40px;">
                
                <h3>2007</h3>
                <p>Mudança de endereço.</p>
                <p>&nbsp;</p>
                <img src="estru/imagens_linha_do_tempo/2007.png" alt="Imagem Linha do Tempo 2007" class="imagem_1998">
                </article>
                
                <article>
                
                <h3>2008</h3>
                <p>Criação do BABY KIT, regulador </p>
                <p>para grade de berços</p>
                <img src="estru/imagens_linha_do_tempo/2008.png" alt="Imagem Linha do Tempo 2008" class="imagem_1998">
                </article>
                
                <article>
                
                <h3>2009</h3>
                <p>Ampliação do Mix de Produtos</p>
                <p>&nbsp;</p>
                <img src="estru/imagens_linha_do_tempo/2009.png" alt="Imagem Linha do Tempo 2009" class="imagem_1998">
                </article>
            
            <article>
                
                <h3>2010</h3>
                <p>Atualização do Logo.</p>
                <p>&nbsp;</p>
                <img src="estru/imagens_linha_do_tempo/2010.png" alt="Imagem Linha do Tempo 2010" class="imagem_1998">
                </article>
                
                 <article style="margin-left: 15px;">
                
                <h3>2012</h3>
                <p>Participação nas feiras</p>
                <p>FIQ e Formóbile.</p>
                
                <img src="estru/imagens_linha_do_tempo/2012.png" alt="Imagem Linha do Tempo 2012" class="imagem_1998">
                </article>
                
              <article>
                
                <h3>2013</h3>
                <p>Participação nas feiras:</p>
                <p> FIMMA /  FITECMA-ARG / INTERZUM-ALE.   <br>
                Conquista da Menção Honrosa  Especial (FIMMA 2013).</p>
<img src="estru/imagens_linha_do_tempo/2013.png" alt="Imagem Linha do Tempo 2013" style="
    margin: 5px 0px 0px 0px;
">
                </article>
            
            </div><!--linha_do_tempo-->
            
            </div><!--CSS INLINE-->
        
        </section><!--empresa-->
    
    
    
    
    
    
    	
    
    
    </section><!--conteudo-->
    
  </div><!--back_conteudo-->
  
    	
    
    
    
  <?php require 'footer.php'; ?>
    
    </section><!--/all-->
    
  
  
    
    


</body>
</html>