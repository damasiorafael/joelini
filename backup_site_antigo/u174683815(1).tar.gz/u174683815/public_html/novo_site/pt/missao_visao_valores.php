<?php $title = 'Empresa - Joelini Ferragens para Móveis'; ?>
<?php require 'header.php'; ?>

<body>

	<?php $menuEmpresa = 'active' ?>
	<?php require 'cabecalho.php'; ?>
    
    
    <section id="all">
    
 
  <div class="back_conteudo">
  
  	<section id="conteudo">
 
    
    
    
    	<section id="missao_visao_valores">
        
        	<h1>Missão, Visão e Valores</h1>
            
            
            <article>
        	<h5>Missão</h5>
            <p>Atender com qualidade e excelência os clientes, angariando informações de mercado, objetivando               assim o desenvolvimento para oferta de novos produtos, instituindo uma concorrência saudável e               contribuindo para geração de novos empregos.</p>
            </article>
            
            
            <article>
        	<h5>Visão</h5>
            <p>Atender com qualidade e excelência os clientes, angariando informações de mercado, objetivando               assim o desenvolvimento para oferta de novos produtos, instituindo uma concorrência saudável e               contribuindo para geração de novos empregos.</p>
            </article>
            
            
            
            <article>
        	<h5>Valores</h5>
            <p>Atender com qualidade e excelência os clientes, angariando informações de mercado, objetivando               assim o desenvolvimento para oferta de novos produtos, instituindo uma concorrência saudável e               contribuindo para geração de novos empregos.</p>
            </article>
        	
        
        </section><!--missao_visao_valores-->
    
    
    
    
    </section><!--conteudo-->
    
  </div><!--back_conteudo-->
  
    	
    
    
    
  <?php require 'footer.php'; ?>
    
    </section><!--/all-->
    
  
  
    
    


</body>
</html>