<?php $title = 'Empresa - Joelini Ferragens para Móveis'; ?>
<?php require 'header.php'; ?>

<body>

	<?php $menuEmpresa = 'active' ?>
	<?php require 'cabecalho.php'; ?>
    
    
    <section id="all">
    
 
  <div class="back_conteudo">
  
  	<section id="conteudo">
 
    
    
    
    	<section id="palavra_do_fundador">
        
        	<h1>Diferenciais joelini</h1>
            
               
        	<center>
           	  <img src="estru/diferenciais_joelini.png" height="372" alt="Diferenciais joelini">
            </center>
        	
        
        </section><!--palavra_do_fundador-->
    
    
    
    
    </section><!--conteudo-->
    
  </div><!--back_conteudo-->
  
    	
    
    
    
  <?php require 'footer.php'; ?>
    
    </section><!--/all-->
    
  
  
    
    


</body>
</html>